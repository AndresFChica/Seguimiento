package com.example.Criminales;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CriminalesApplicationTests {

	@Test
	void contextLoads() {
	}

}
